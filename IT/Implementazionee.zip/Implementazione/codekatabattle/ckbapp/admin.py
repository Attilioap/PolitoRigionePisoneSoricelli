# ckbapp/admin.py

from django.contrib import admin
from .models import User, Student, Educator, Team, Tournament, Battle
from django.contrib.auth.models import Group

# Create Educator group
educator_group, created = Group.objects.get_or_create(name='Educators')

# Create Student group
student_group, created = Group.objects.get_or_create(name='Students')


admin.site.register(User)
admin.site.register(Student)
admin.site.register(Educator)
admin.site.register(Team)
admin.site.register(Tournament)
admin.site.register(Battle)
