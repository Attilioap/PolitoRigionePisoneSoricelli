from django.shortcuts import render, redirect
from .models import Tournament, Educator, Student
from django.contrib import messages
from datetime import datetime
from .forms import SignupForm
from django.contrib.auth.models import User, Group
from django.contrib.auth.hashers import make_password
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required

def tournament_list():
    tournaments = Tournament.objects.all()
    past_tournaments=[tournament for tournament in tournaments if tournament.endingDate < datetime.now().date()]
    ongoing_tournaments=[tournament for tournament in tournaments if tournament.endingDate >= datetime.now().date()]
    return ongoing_tournaments, past_tournaments
'''
def student_tournament_list(student):
    subscribed_tournaments = student.tournaments_subscribed.all()
    past_tournaments = [tournament for tournament in subscribed_tournaments if tournament.endingDate < datetime.now().date()]
    upcoming_tournaments = [tournament for tournament in subscribed_tournaments if tournament.endingDate >= datetime.now().date()]
    return subscribed_tournaments, upcoming_tournaments, past_tournaments
    '''


def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():

            firstName = form.cleaned_data['firstName']
            lastName = form.cleaned_data['lastName']
            email = form.cleaned_data['email']
            username = form.cleaned_data['username']
            password1 = form.cleaned_data['password1']
            is_educator = form.cleaned_data['is_educator']

        
            # Create User object
            user = User.objects.create(
                first_name=firstName,
                last_name=lastName,
                email=email,
                username=username,
                password=make_password(password1),
            )

            
            
            # Assign User to the appropriate group
            if is_educator:
                educator_group = Group.objects.get(name='Educators')
                educator_group.user_set.add(user)
                Educator.objects.create(user=user)
            else:
                student_group = Group.objects.get(name='Students')
                student_group.user_set.add(user)
                Student.objects.create(user=user)

            user = authenticate(request, username=username, password=password1)
            login(request, user)
            # Redirect to login or home page as appropriate
            return redirect('educator_dash')  

    else:
        form = SignupForm()

    return render(request, 'ckbapp/signup.html', {'form': form})



def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)

                # Check user's group and redirect accordingly
                if user.groups.filter(name='Educators').exists():
                    return redirect('educator_dash')  # You need to define the educator dashboard URL
                elif user.groups.filter(name='Students').exists():
                    return redirect('student_dash')  # You need to define the student dashboard URL
                else:
                    return redirect('dashboard')  # Default redirect if not in 'Educators' or 'Students'

            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = AuthenticationForm()

    return render(request, 'ckbapp/login.html', {'form': form})



def educator_dash(request):
    if request.method == 'POST':
        # Handle form submission
        name = request.POST.get('tournament_name')
        registration_deadline = request.POST.get('registration_deadline')
        ending_date = request.POST.get('ending_date')
        description = request.POST.get('description')

        # Validate and create the tournament
        if name and registration_deadline and ending_date and description:
            # Parse date strings to datetime objects
            registration_deadline = datetime.strptime(registration_deadline, '%Y-%m-%d')
            ending_date = datetime.strptime(ending_date, '%Y-%m-%d')
            
  
            if registration_deadline.date() >= datetime.now().date() and ending_date.date() > datetime.now().date() and ending_date.date() > registration_deadline.date():
                Tournament.objects.create(
                    name=name,
                    registrationDeadline=registration_deadline,
                    endingDate=ending_date,
                    description=description
                )

                # Redirect to the educator dashboard
                return redirect('educator_dash')
            else:
                # Add an error message
                messages.error(request, "Invalid dates. Registration deadline must be after or on today, and ending date must be after today. They also cannot be the same date")
                return redirect('educator_dash')

     # Handle GET request
    educator = request.user.educator  # Assuming the educator is logged in
    ongoing_tournaments = Tournament.objects.filter(educators=educator, endingDate__gte=datetime.now().date())
    past_tournaments = Tournament.objects.filter(educators=educator, endingDate__lt=datetime.now().date())


    return render(request, 'ckbapp/educator_dashboard.html', {'ongoing_tournaments': ongoing_tournaments, 'past_tournaments': past_tournaments})


'''
def student_dash(request):
    # Assuming you have a way to identify the logged-in student (for example, using Django's authentication system)
    # Replace the following line with the logic to get the current student
    student = Student.objects.get(id=1)  # Replace with the actual method to get the logged-in student

    subscribed_tournaments, upcoming_tournaments, past_tournaments = student_tournament_list(student)
    return render(request, 'ckbapp/student_dashboard.html', {
        'subscribed_tournaments': subscribed_tournaments,
        'upcoming_tournaments': upcoming_tournaments,
        'past_tournaments': past_tournaments
    })
'''