# forms.py
from django import forms
from django.contrib.admin.widgets import FilteredSelectMultiple
from .models import Tournament

class SignupForm(forms.Form):
    firstName = forms.CharField(max_length=255, required=True)
    lastName = forms.CharField(max_length=255, required=True)
    email = forms.EmailField(required=True)
    password1 = forms.CharField(widget=forms.PasswordInput, required=True)
    username = forms.CharField(max_length=255, required=True)
    is_educator = forms.BooleanField(required=False)

class TournamentAdminForm(forms.ModelForm):
    class Meta:
        model = Tournament
        fields = '__all__'
        widgets = {
            'educators': FilteredSelectMultiple('Educators', is_stacked=False),
            'students': FilteredSelectMultiple('Students', is_stacked=False),
        }
