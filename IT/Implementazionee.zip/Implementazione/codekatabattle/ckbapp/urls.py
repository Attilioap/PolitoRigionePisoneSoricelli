from django.contrib import admin
from django.urls import path
from .views import educator_dash, signup, user_login

urlpatterns = [
    path('educator_dashboard/', educator_dash, name='educator_dash'),
    path('signup/', signup, name='signup'),
    path('login/', user_login, name ='login'),
]
